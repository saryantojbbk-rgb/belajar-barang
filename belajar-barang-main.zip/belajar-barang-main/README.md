# belajar-barang
CRUD Laravel untuk data barang
